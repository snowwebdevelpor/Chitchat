-- Chit Chat update #2: voice notes, photos, View Once, replies. Run ONCE in SQL Editor AFTER schema.sql. Does not delete data.
alter table public.messages add column if not exists kind text not null default 'text' check (kind in ('text','voice','image','view_once'));
alter table public.messages add column if not exists media_path text;
alter table public.messages add column if not exists duration int;
alter table public.messages add column if not exists viewed_at timestamptz;
alter table public.messages add column if not exists reply_to bigint references public.messages(id) on delete set null;
alter table public.messages drop constraint if exists messages_body_check;
alter table public.messages drop constraint if exists messages_body_ok;
alter table public.messages add constraint messages_body_ok check ((kind='text' and length(body) between 1 and 2000) or (kind<>'text' and length(body)<=2000 and media_path is not null));
drop policy if exists "msg insert" on public.messages;
create policy "msg insert" on public.messages for insert to authenticated with check (
 sender=auth.uid() and (media_path is null or media_path like sender::text||'/%') and viewed_at is null
 and exists(select 1 from public.friendships f where f.status='accepted' and ((f.requester=sender and f.addressee=recipient) or (f.requester=recipient and f.addressee=sender))));
-- atomic one-time claim: only the recipient, only once
create or replace function public.consume_view_once(msg_id bigint) returns text language sql security definer set search_path=public as $$
update public.messages set viewed_at=now() where id=msg_id and recipient=auth.uid() and kind='view_once' and viewed_at is null returning media_path $$;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('chat-media','chat-media',false,5242880,array['image/jpeg','image/png','image/webp','audio/webm','audio/mp4','audio/ogg']) on conflict (id) do nothing;
drop policy if exists "cm insert" on storage.objects; drop policy if exists "cm read" on storage.objects; drop policy if exists "cm delete" on storage.objects;
create policy "cm insert" on storage.objects for insert to authenticated with check (bucket_id='chat-media' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "cm delete" on storage.objects for delete to authenticated using (bucket_id='chat-media' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "cm read" on storage.objects for select to authenticated using (bucket_id='chat-media' and (
 (storage.foldername(name))[1]=auth.uid()::text
 or exists(select 1 from public.messages m where m.media_path=name and m.recipient=auth.uid() and (m.kind in ('voice','image') or (m.kind='view_once' and m.viewed_at>now()-interval '2 minutes')))));
