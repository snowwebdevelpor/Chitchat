-- Chit Chat schema. Run ONCE in a NEW Supabase project (SQL Editor). Safe to re-run: uses IF NOT EXISTS / OR REPLACE.
create table if not exists public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null check (username ~ '^[a-z0-9_]{3,20}$'),
 display_name text not null default '', bio text not null default '' check (length(bio)<=200),
 avatar_url text, created_at timestamptz default now());
create unique index if not exists profiles_username_key on public.profiles(lower(username));
create table if not exists public.friendships(
 id bigint generated always as identity primary key,
 requester uuid not null references public.profiles(id) on delete cascade,
 addressee uuid not null references public.profiles(id) on delete cascade,
 status text not null default 'pending' check (status in ('pending','accepted')),
 created_at timestamptz default now(), check (requester<>addressee));
create unique index if not exists friendships_pair on public.friendships(least(requester,addressee),greatest(requester,addressee));
create table if not exists public.messages(
 id bigint generated always as identity primary key,
 sender uuid not null references public.profiles(id) on delete cascade,
 recipient uuid not null references public.profiles(id) on delete cascade,
 body text not null check (length(body) between 1 and 2000),
 created_at timestamptz default now(), read_at timestamptz);
create index if not exists messages_pair_idx on public.messages(sender,recipient,created_at);
alter table public.profiles enable row level security;
alter table public.friendships enable row level security;
alter table public.messages enable row level security;
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,username,display_name) values(new.id,lower(new.raw_user_meta_data->>'username'),coalesce(nullif(new.raw_user_meta_data->>'display_name',''),new.raw_user_meta_data->>'username')); return new; end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
create or replace function public.mark_read(other uuid) returns void language sql security definer set search_path=public as $$
update public.messages set read_at=now() where recipient=auth.uid() and sender=other and read_at is null $$;
drop policy if exists "profiles read" on public.profiles; drop policy if exists "profiles update own" on public.profiles;
create policy "profiles read" on public.profiles for select to authenticated using (true);
create policy "profiles update own" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());
drop policy if exists "fr read" on public.friendships; drop policy if exists "fr insert" on public.friendships; drop policy if exists "fr accept" on public.friendships; drop policy if exists "fr delete" on public.friendships;
create policy "fr read" on public.friendships for select to authenticated using (auth.uid() in (requester,addressee));
create policy "fr insert" on public.friendships for insert to authenticated with check (requester=auth.uid() and status='pending');
create policy "fr accept" on public.friendships for update to authenticated using (addressee=auth.uid()) with check (addressee=auth.uid() and status='accepted');
create policy "fr delete" on public.friendships for delete to authenticated using (auth.uid() in (requester,addressee));
drop policy if exists "msg read" on public.messages; drop policy if exists "msg insert" on public.messages; drop policy if exists "msg delete" on public.messages;
create policy "msg read" on public.messages for select to authenticated using (auth.uid() in (sender,recipient));
create policy "msg insert" on public.messages for insert to authenticated with check (sender=auth.uid() and exists(select 1 from public.friendships f where f.status='accepted' and ((f.requester=sender and f.addressee=recipient) or (f.requester=recipient and f.addressee=sender))));
create policy "msg delete" on public.messages for delete to authenticated using (sender=auth.uid());
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('avatars','avatars',true,2097152,array['image/jpeg','image/png','image/webp']) on conflict (id) do nothing;
drop policy if exists "avatar insert" on storage.objects; drop policy if exists "avatar update" on storage.objects; drop policy if exists "avatar delete" on storage.objects;
create policy "avatar insert" on storage.objects for insert to authenticated with check (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "avatar update" on storage.objects for update to authenticated using (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "avatar delete" on storage.objects for delete to authenticated using (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);
do $$ begin alter publication supabase_realtime add table public.messages; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.friendships; exception when duplicate_object then null; end $$;
