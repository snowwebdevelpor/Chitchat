# Chit Chat 💗 – setup from an Android phone
1. supabase.com → New project (use a NEW project, not your old one). Save the DB password.
2. Project → SQL Editor (run schema.sql, THEN a second query with schema2.sql for voice/photos/View Once) → New query → paste all of `schema.sql` → Run. Expect "Success".
3. Authentication → Providers → Email is on. (Optional: turn off "Confirm email" while testing.)
4. Authentication → URL Configuration → Site URL = your GitHub Pages address (e.g. https://YOURNAME.github.io/chit-chat/). Add it under Redirect URLs too (needed for password reset).
5. Project Settings → API: copy Project URL and the anon/publishable key. NEVER use the service_role key.
6. Edit `index.html` on GitHub (pencil icon): paste both values at the top of the script.
7. GitHub: new repo → Add file → Upload files (index.html, sw.js, manifest.webmanifest, icon-192.png, icon-512.png, schema.sql, and the `fonts` folder with emoji.ttf). Settings → Pages → Deploy from branch → main / root.
8. Open the Pages link in Chrome → ⋮ → Install app / Add to Home screen.
Free-plan notes: Supabase free tier pauses projects after about a week of inactivity; avatars limited to 2 MB in the bucket (the app shrinks photos to 512px first). GitHub Pages is free for public repos.
Built (untested): voice notes, photos, View Once (one-time claim in the database, 2-minute signed link; screenshots can't be blocked; files are not auto-deleted after opening), replies. Not yet built: push notifications, typing/online status, calls. Not tested end-to-end: only the JS syntax was checked.
